#!/usr/bin/env python3

# Copyright (C) 2018, Vi Grey
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY AUTHOR AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

# Last Updated (2018-09-25)

import sys

# Check if help flag was passed as an argument
if len(sys.argv) >= 2:
    if sys.argv[1] == "--help" or sys.argv[1] == "-h":
        print("Takes an input brainf--k file and prints interpreted output " +
              "to STDOUT\r\n\r\n" +
              "Usage: python3 bfinterpreter.py [ <input_file> ]\r\n\r\n" +
              "Options:\r\n"
              "  -h, --help        Print Help (this message) and exit\r\n\r\n"
              "Example:\r\n" +
              "  python3 bfinterpreter.py test.bf")
        exit(0)
    elif len(sys.argv) > 2:
      print("\x1b[91mbfinterpreter: invalid option -- " + sys.argv[1] + "\r\n" +
            "Try 'python3 bfinterpreter.py --help' for more information." +
            "\x1b[0m\r\n")
      exit(1)
else:
    print("\x1b[91mbfinterpreter: missing argument\r\n" +
        "Try 'python3 bfinterpreter.py --help' for more information." +
        "\x1b[0m\r\n")
    exit(1)

filepath = sys.argv[1]

bf_file = open(filepath, "rb")
instructions = bf_file.read()
bf_file.close()

memory = [0] * 30000
memptr = 0
instptr = 0
squares = 0

while True:
    inst = instructions[instptr]
    if inst == ord("+"):
        memory[memptr] += 1
        if memory[memptr] == 256:
            memory[memptr] = 0
    elif inst == ord("-"):
        memory[memptr] -= 1
        if memory[memptr] == -1:
            memory[memptr] = 255
    elif inst == ord("<"):
        if memptr > 0:
            memptr -= 1
        else:
            print("\x1b[91mMemory Pointer out of bounds (-1)\x1b[0m")
            exit(1)
    elif inst == ord(">"):
        if memptr < 29999:
            memptr += 1
        else:
            print("\x1b[91mMemory Pointer out of bounds (30000)\x1b[0m")
            exit(1)
    elif inst == ord("."):
        a = []
        a.append(memory[memptr])
        sys.stdout.buffer.write(bytes(a))
    elif inst == ord(","):
        memory[memptr] = ord(input().split(" ")[0])
    elif inst == ord("]"):
        while True:
            instptr -= 1
            inst = instructions[instptr]
            if inst == ord("]"):
                squares += 1
            elif inst == ord("["):
                if squares != 0:
                    squares -= 1
                else:
                    instptr -= 1
                    break
    elif inst == ord("["):
        if memory[memptr] == 0:
            while True:
                instptr += 1
                inst = instructions[instptr]
                if inst == ord("["):
                    squares += 1
                elif inst == ord("]"):
                    if squares != 0:
                        squares -= 1
                    else:
                        break
    instptr += 1
    if instptr == len(instructions):
        break

print()
